/*
 * Copyright (C) 2022 Igalia S.L.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public License
 * along with this library; see the file COPYING.LIB.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA 02110-1301, USA.
 */

#ifdef __WEBKIT_WEB_EXTENSION_H__
#error "Headers <webkit2/webkit2.h> and <webkit/webkit-web-extension.h> cannot be included together."
#endif

#ifndef __WEBKIT_H__
#define __WEBKIT_H__

#define __WEBKIT_H_INSIDE__

#include <webkit/WebKitApplicationInfo.h>
#include <webkit/WebKitAuthenticationRequest.h>
#include <webkit/WebKitAutomationSession.h>
#include <webkit/WebKitBackForwardList.h>
#include <webkit/WebKitBackForwardListItem.h>
#include <webkit/WebKitClipboardPermissionRequest.h>
#include <webkit/WebKitColorChooserRequest.h>
#include <webkit/WebKitContextMenu.h>
#include <webkit/WebKitContextMenuActions.h>
#include <webkit/WebKitContextMenuItem.h>
#include <webkit/WebKitCookieManager.h>
#include <webkit/WebKitCredential.h>
#include <webkit/WebKitDefines.h>
#include <webkit/WebKitDeviceInfoPermissionRequest.h>
#include <webkit/WebKitDownload.h>
#include <webkit/WebKitEditingCommands.h>
#include <webkit/WebKitEditorState.h>
#include <webkit/WebKitEnumTypes.h>
#include <webkit/WebKitError.h>
#include <webkit/WebKitFaviconDatabase.h>
#include <webkit/WebKitFeature.h>
#include <webkit/WebKitFileChooserRequest.h>
#include <webkit/WebKitFindController.h>
#include <webkit/WebKitFormSubmissionRequest.h>
#include <webkit/WebKitGeolocationManager.h>
#include <webkit/WebKitGeolocationPermissionRequest.h>
#include <webkit/WebKitHitTestResult.h>
#include <webkit/WebKitInputMethodContext.h>
#include <webkit/WebKitInstallMissingMediaPluginsPermissionRequest.h>
#include <webkit/WebKitJavascriptResult.h>
#include <webkit/WebKitMediaKeySystemPermissionRequest.h>
#include <webkit/WebKitMemoryPressureSettings.h>
#include <webkit/WebKitMimeInfo.h>
#include <webkit/WebKitNavigationAction.h>
#include <webkit/WebKitNavigationPolicyDecision.h>
#include <webkit/WebKitNetworkProxySettings.h>
#include <webkit/WebKitNotification.h>
#include <webkit/WebKitNotificationPermissionRequest.h>
#include <webkit/WebKitOptionMenu.h>
#include <webkit/WebKitOptionMenuItem.h>
#include <webkit/WebKitPermissionRequest.h>
#include <webkit/WebKitPermissionStateQuery.h>
#include <webkit/WebKitPlugin.h>
#if (defined(ENABLE_POINTER_LOCK) && ENABLE_POINTER_LOCK)
#include <webkit/WebKitPointerLockPermissionRequest.h>
#endif
#include <webkit/WebKitPrintCustomWidget.h>
#include <webkit/WebKitPrintOperation.h>
#include <webkit/WebKitResponsePolicyDecision.h>
#include <webkit/WebKitScriptDialog.h>
#include <webkit/WebKitSecurityManager.h>
#include <webkit/WebKitSecurityOrigin.h>
#include <webkit/WebKitSettings.h>
#include <webkit/WebKitURIRequest.h>
#include <webkit/WebKitURIResponse.h>
#include <webkit/WebKitURISchemeRequest.h>
#include <webkit/WebKitURISchemeResponse.h>
#include <webkit/WebKitURIUtilities.h>
#include <webkit/WebKitUserContent.h>
#include <webkit/WebKitUserContentFilterStore.h>
#include <webkit/WebKitUserContentManager.h>
#include <webkit/WebKitUserMediaPermissionRequest.h>
#include <webkit/WebKitUserMessage.h>
#include <webkit/WebKitVersion.h>
#include <webkit/WebKitWebContext.h>
#include <webkit/WebKitWebInspector.h>
#include <webkit/WebKitWebResource.h>
#include <webkit/WebKitWebView.h>
#include <webkit/WebKitWebViewBase.h>
#include <webkit/WebKitWebViewSessionState.h>
#include <webkit/WebKitWebsiteData.h>
#include <webkit/WebKitWebsiteDataAccessPermissionRequest.h>
#include <webkit/WebKitWebsiteDataManager.h>
#include <webkit/WebKitWindowProperties.h>
#include <webkit/WebKitXRPermissionRequest.h>

#include <webkit/WebKitAutocleanups.h>

#undef __WEBKIT_H_INSIDE__

#endif /* __WEBKIT_H__ */
